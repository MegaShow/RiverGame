
function stageFirst() {
  var msgList = new Array('我是谁？', '我这是在哪里？');
  talk(msgList, tmp);

  function tmp() {
    playerNow.x = 100;
    playerNow.y = 100;
    containerNow.addChild(playerNow);
    bppStart();
    stageStreet();
  }
}



function stage2() {
  var gameBG2 = PIXI.Sprite.fromImage('rc/gameBG.png');
  var gameBG3 = PIXI.Sprite.fromImage('rc/gameStart.png');
  containerOld.addChild(gameBG3);
  containerNow.addChild(gameBG2);
  containerOld.alpha = 0.8;
  displayNow();
  updateTimeButton();

  var manBodyNow = PIXI.Sprite.fromImage('rc/take1.png');
  var manBodyOld = PIXI.Sprite.fromImage('rc/take1.png');

  manBodyNow.height = 200;
  manBodyNow.width = 100;
  manBodyOld.height = 200;
  manBodyOld.width = 100;
  containerNow.addChild(manBodyNow);
  containerOld.addChild(manBodyOld);

  moveTo(manBodyOld, 100, 600);

}


// 五羊
function stagePark() {
  var gameBGNow = PIXI.Sprite.fromImage('rc/park.jpg');
  var gameBGOld = PIXI.Sprite.fromImage('rc/park.jpg');
  containerNow.addChild(gameBGNow);
  containerOld.addChild(gameBGOld);
}


// 上下九
function stageStreet() {
  var gameBGNow = PIXI.Sprite.fromImage('rc/street.png');
  var gameBGOld = PIXI.Sprite.fromImage('rc/street.png');
  containerNow.addChild(gameBGNow);
  containerOld.addChild(gameBGOld);

  var npcSellNow = PIXI.Sprite.fromImage('rc/npcSell.png');
  var npcSellOld = PIXI.Sprite.fromImage('rc/npcSell.png');
  npcCreate(npcSellNow, npcSellOld, 100, 0, npcFoodClick);


  // 鸡公榄(黄牛)
  var npcFoodNow = PIXI.Sprite.fromImage('rc/npcFood.png');
  var npcFoodOld = PIXI.Sprite.fromImage('rc/npcYellow.png');
  npcCreate(npcFoodNow, npcFoodOld, 100, 0, npcFoodClick);

  function npcFoodClick() {
    if (nowtime == true && isGirlLeave == false) {
      talk(["老汉: 鸡公榄要不要啊, 靓女?", "???: 给我一包."]);
    }
    else if (nowtime == true && isGirlLeave == true) {
      talk(["老汉: 鸡公榄要不要啊, 靓女?"]);
    }
    else if (nowtime == false) {
      talk(["黄老汉: 走过路过不要错过啊, 全上下九我最便!", "???: ???"]);
    }
  }


  // 小女孩(车夫)
  var npcGirlNow = isGirlLeave ? null : PIXI.Sprite.fromImage('rc/npcGirl.png');
  var npcGirlOld = PIXI.Sprite.fromImage('rc/npcCar.png');
  npcCreate(npcGirlNow, npcGirlOld, 100, 0, npcGirlClick);

  function npcGirlClick() {
    if (nowtime == true && item[0] == true) {
      talk(["???: (递给小女孩鸡公榄)",
        "小女孩: 谢谢姐姐!",
        "???: 不客气."]);
      isGirlLeave = true;
      containerNow.removeChild(npcGirlNow);
      talk(["???: 这是什么?"]);
      getItem(1);
      displayNow();
      updateTimeButton();
    }
    else if (nowtime == true && isGirlLeave == false) {
      talk(["小女孩: 呜呜呜~我要鸡公榄嘛~呜~",
        "???: (这个小女孩好眼熟啊)"]);
    }
    else if (nowtime == false) {
      talk(["壮年男子: 小姐坐车么?", "???: 好."]);
    }
  }


  // 售票员(售票员)
  function npcSoldClick() {
    if (nowtime == 1) {
      talk(["售票员: 在这里卖了十多年票了, 什么时候才有出路.", "???: 母鸡啊!"]);
    } else if (nowtime == 0) {
      talk(["售票员: 你好, 我是这里的新职员, 不要跟老板说我偷懒哦.", "???: 嘤嘤嘤."]);
    }
  }


}


// 珠江
function stageRiver() {
  var gameBGNow = PIXI.Sprite.fromImage('rc/river.jpg');
  var gameBGOld = PIXI.Sprite.fromImage('rc/river.jpg');
  containerNow.addChild(gameBGNow);
  containerOld.addChild(gameBGOld);


}



//////////////////////////////////////////////////
function npcCreate(npcNow, npcOld, x, y, func) {
  if (npcNow != null) {
    npcNow.x = x;
    npcNow.y = y;
    containerNow.addChild(npcNow);
    npcNow.interactive = true;
    npcNow.buttonMode = true;
    npcNow.on('pointerdown', func);
  }
  if (npcOld != null) {
    npcOld.x = x;
    npcOld.y = y;

    containerOld.addChild(npcOld);

    npcOld.interactive = true;
    npcOld.buttonMode = true;
    npcOld.on('pointerdown', func);
  }
}


function getItem(type) {
  if (type >= 0 && type <= 10) {
    item[type] = true;
    talk(["获得" + itemStr[i]]);
  }
}