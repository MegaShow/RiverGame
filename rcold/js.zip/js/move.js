function moveTo(man, posX, posY) {
  var walkR1 = PIXI.Texture.fromImage('rc/walkr1.png');
  var walkR2 = PIXI.Texture.fromImage('rc/walkr2.png');
  var walkL1 = PIXI.Texture.fromImage('rc/walkl1.png');
  var walkL2 = PIXI.Texture.fromImage('rc/walkl2.png');
  var walk1;
  var walk2;
  var takeTime = new PIXI.ticker.Ticker();
  takeTime.started = false;
  takeTime.speed = 0.03;
  var count_m = 0;
  var movespeedx = (posX - man.x);
  var movespeedy = (posY - man.y);
  if(movespeedx > 0){
    movespeedx = 10;
    walk1 = walkR1;
    walk2 = walkR2;
  } else {
    movespeedx = -10;
    walk1 = walkL1;
    walk2 = walkL2;
  }
  if(movespeedy > 0){
    movespeedy = 10;
  } else {
    movespeedy = -10;
  }
  takeTime.add(function(){
    count_m++;
    if (count_m > 3) count_m = 0;

    switch (count_m) {
      case 0:
      man.texture = take1;
      break;
      case 1:
      man.texture = take2;
      break;
      case 3:
      man.texture = take3;
      break;
    }
    if (Math.abs(posX - man.x) < 15 && Math.abs(posY - man.y) < 15){
      takeTime.stop();
    }
    if (Math.abs(posX - man.x) > 11) {
      man.x += movespeedx;
    }
    if (Math.abs(posY - man.y) > 11) {
      man.y += movespeedy;
    }

  });

  takeTime.start();
}
