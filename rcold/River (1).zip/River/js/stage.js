
function stageFirst() {
  var msgList = new Array('我是谁？', '我这是在哪里？');
  talk(msgList, tmp);

  function tmp() {
    bppStart();
    containerOld.alpha = 0.8;
    displayNow();
    containerOld.x = - app.renderer.width / 4;
    updateTimeButton();
    stageStreet();
  }
}



/*function stage2() {
  var gameBG2 = PIXI.Sprite.fromImage('rc/gameBG.png');
  var gameBG3 = PIXI.Sprite.fromImage('rc/gameStart.png');
  containerOld.addChild(gameBG3);
  containerNow.addChild(gameBG2);
  containerOld.alpha = 0.8;
  displayNow();
  updateTimeButton();

  var manBodyNow = PIXI.Sprite.fromImage('rc/take1.png');
  var manBodyOld = PIXI.Sprite.fromImage('rc/take1.png');

  manBodyNow.height = 200;
  manBodyNow.width = 100;
  manBodyOld.height = 200;
  manBodyOld.width = 100;
  containerNow.addChild(manBodyNow);
  containerOld.addChild(manBodyOld);

  moveTo(manBodyOld, 100, 600);

}*/


// 五羊
function stagePark() {
  var gameBGNow = PIXI.Sprite.fromImage('rc/park.png');
  var gameBGOld = PIXI.Sprite.fromImage('rc/park.png');
  createBG(gameBGNow, gameBGOld);

  npcCreate(playerNow, playerOld, 50, 400, null);


}




// 上下九
function stageStreet() {
  var gameBGNow = PIXI.Sprite.fromImage('rc/street.png');
  var gameBGOld = PIXI.Sprite.fromImage('rc/park.png');
  createBG(gameBGNow, gameBGOld);

  npcCreate(playerNow, playerOld, 50, 400, null);

  // 鸡公榄(黄牛)
  var npcFoodNow = PIXI.Sprite.fromImage('rc/npcFood.png');
  var npcFoodOld = PIXI.Sprite.fromImage('rc/npcYellow.png');
  npcCreate(npcFoodNow, npcFoodOld, 750, 250, npcFoodClick);

  function npcFoodClick() {
    moveTo(playerNow, this.x, this.y);
    if (nowtime == true && isGirlLeave == false && isNeedFood == true && item[0] == false) {
      talk(["老汉: 鸡公榄要不要啊, 靓女?", "???: 给我一包."]);
      getItem(0);
    }
    else if (nowtime == true) {
      talk(["老汉: 鸡公榄要不要啊, 靓女?"]);
    }
    else if (nowtime == false) {
      talk(["黄老汉: 走过路过不要错过啊, 全上下九我最便!", "???: ???"]);
    }
  }


  // 小女孩(车夫)
  var npcGirlNow = isGirlLeave ? null : PIXI.Sprite.fromImage('rc/staker.png');
  var npcGirlOld = PIXI.Sprite.fromImage('rc/npcCar.png');
  npcCreate(npcGirlNow, npcGirlOld, 150, 300, npcGirlClick);

  function npcGirlClick() {
    moveTo(playerNow, this.x, this.y);
    if (nowtime == true && item[0] == true && isGirlLeave == false) {
      talk(["???: (递给小女孩鸡公榄)",
        "小女孩: 谢谢姐姐!",
        "???: 不客气.",
        "???: 这是什么?"]);
      isGirlLeave = true;
      getItem(1);
    }
    else if (nowtime == true && isGirlLeave == false) {
      talk(["小女孩: 呜呜呜~我要鸡公榄嘛~呜~",
        "???: (这个小女孩好眼熟啊)"]);
      isNeedFood = true;
    }
    else if (nowtime == false) {
      talk(["壮年男子: 小姐坐车么?", "???: 好."]);
    }
  }


  // 售票员(售票员)
  var npcSoldNow = isGirlLeave ? null : PIXI.Sprite.fromImage('rc/stakel.png');
  var npcSoldOld = PIXI.Sprite.fromImage('rc/npcSold.png');
  npcCreate(npcSoldNow, npcSoldOld, 550, 280, npcSoldClick);

  function npcSoldClick() {
    moveTo(playerNow, this.x, this.y);
    if (nowtime == 1) {
      talk(["售票员: 在这里卖了十多年票了, 什么时候才有出路.", "???: 母鸡啊!"]);
    } else if (nowtime == 0) {
      talk(["售票员: 你好, 我是这里的新职员, 不要跟老板说我偷懒哦.", "???: 嘤嘤嘤."]);
    }
  }


  var goPart = PIXI.Sprite.fromImage('rc/npcFood.png');
  npcCreate(goPart, null, 1000, 400, funcGoPart);

  function funcGoPart() {
    containerNow.removeChildren();
    containerOld.removeChildren();
    /*containerNow.removeChild(gameBGNow);
    containerNow.removeChild(playerNow);
    containerNow.removeChild(npcFoodNow);
    containerNow.removeChild(npcGirlNow);
    containerNow.removeChild(npcSoldNow);
    
    containerOld.removeChild(gameBGOld);
    containerOld.removeChild(playerOld);
    containerOld.removeChild(npcFoodOld);
    containerOld.removeChild(npcGirlOld);
    containerOld.removeChild(npcSoldOld);

    containerNow.removeChild(goPart);*/

    stagePark();
  }

}


// 珠江
function stageRiver() {
  var gameBGNow = PIXI.Sprite.fromImage('rc/river.jpg');
  var gameBGOld = PIXI.Sprite.fromImage('rc/river.jpg');
  containerNow.addChild(gameBGNow);
  containerOld.addChild(gameBGOld);


}



//////////////////////////////////////////////////

function npcCreate(npcNow, npcOld, x, y, func) {
  if (npcNow != null) {
    npcNow.x = x;
    npcNow.y = y;
    if (nowtime == 0) {
      npcNow.x = x / 4;
      npcNow.y = y / 4;
      npcNow.width = npcNow.width / 4;
      npcNow.length = npcNow.length / 4;
    }
    containerNow.addChild(npcNow);
    npcNow.interactive = true;
    npcNow.buttonMode = true;
    npcNow.on('pointerdown', func);
  }
  if (npcOld != null) {
    npcOld.x = x;
    npcOld.y = y;
    if (nowtime == 1) {
      npcOld.x = x / 4;
      npcOld.y = y / 4;
      npcOld.width = npcOld.width / 4;
      npcOld.length = npcOld.length / 4;
    }
    containerOld.addChild(npcOld);

    npcOld.interactive = true;
    npcOld.buttonMode = true;
    npcOld.on('pointerdown', func);
  }
}


function createBG(BGNow, BGOld) {
  BGNow.width = app.renderer.width / (nowtime ? 1 : 4);
  BGNow.height = app.renderer.height / (nowtime ? 1 : 4);
  BGOld.width = app.renderer.width / (nowtime ? 4 : 1);
  BGOld.height = app.renderer.height / (nowtime ? 4 : 1);
  containerNow.addChild(BGNow);
  containerOld.addChild(BGOld);
}



function getItem(type) {
  if (type >= 0 && type <= 10) {
    item[type] = true;
    //talk(["获得" + itemStr[type]]);
  }
}